<?php

class DbConnect{

    private $con;

    function __construct(){

    }

    function connect(){

        require_once "../config/constants.php";

        $this->con = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

        if (mysqli_connect_errno()) {

            echo "Failed to connect to database".mysqli_connect_err();
        }

        return $this->con;
    }
}