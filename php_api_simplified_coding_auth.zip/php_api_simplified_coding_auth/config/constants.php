<?php

define('DB_NAME', 'php_api_simplified_coding');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

?>