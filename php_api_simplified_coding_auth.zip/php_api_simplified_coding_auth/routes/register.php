<?php

require_once "../classes/users.php";

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['username']) and isset($_POST['email']) and isset($_POST['password'])) {

       $db = new Users();

       $result = $db->createUser($_POST['username'], $_POST['password'], $_POST['email']);

       if ($result == 1) {
           $response['error'] = false;
           $response['message'] = "User Registration successful..";
       }elseif($result == 2){
           $response['error'] = true;
           $response['message'] = "Server error!";
       }elseif($result == 0){
           $response['error'] = true;
           $response['message'] = "User exists";
       }

    }else{
        $response['error'] = true;
        $response['message'] = "Required field are missing!";
    }
}else{
    $response['error'] = true;
    $response['message'] = "Invalid Request!";
}

echo json_encode($response);